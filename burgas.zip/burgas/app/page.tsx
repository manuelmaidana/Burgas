'use client';

import Link from 'next/link';
import { motion } from 'framer-motion';
import { useTour, calcStopOverall } from '@/context/TourContext';

const STATUS_LABEL: Record<string, string> = {
  locked: 'Bloqueada',
  'in-progress': 'En progreso',
  done: 'Completada',
};

const STOP_NUMS = ['01', '02', '03', '04'];

export default function HomePage() {
  const { state } = useTour();
  const doneCount = state.stops.filter(s => s.status === 'done').length;

  return (
    <main style={{ paddingBottom: 'calc(80px + env(safe-area-inset-bottom, 0px))', paddingTop: 'calc(16px + env(safe-area-inset-top, 0px))', minHeight: '100dvh' }}>
      <div style={{ padding: '16px 20px 12px' }}>
        <motion.h1
          initial={{ opacity: 0, y: -12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ type: 'spring', stiffness: 300, damping: 28 }}
          className="font-display"
          style={{ fontSize: 44, color: 'var(--text)', margin: 0, lineHeight: 1 }}
        >
          Burger Tour
        </motion.h1>
        <motion.p
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.12 }}
          style={{ color: 'var(--text-muted)', fontSize: 14, margin: '6px 0 0' }}
        >
          Maida &middot; Gena &middot; Fran &mdash; 4 paradas
        </motion.p>
      </div>

      <div style={{ padding: '0 20px 20px' }}>
        <div style={{ display: 'flex', gap: 6, alignItems: 'center' }}>
          {state.stops.map((stop) => (
            <div
              key={stop.id}
              className={`dot ${stop.status === 'in-progress' ? 'active' : stop.status === 'done' ? 'done' : ''}`}
            />
          ))}
          <span style={{ marginLeft: 8, fontSize: 12, color: 'var(--text-muted)' }}>
            {doneCount}/4 completadas
          </span>
        </div>
      </div>

      <div style={{ padding: '0 16px', display: 'flex', flexDirection: 'column', gap: 12 }}>
        {state.stops.map((stop, i) => {
          const isLocked = stop.status === 'locked';
          const avg = stop.status === 'done' ? calcStopOverall(stop) : null;

          return (
            <motion.div
              key={stop.id}
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ type: 'spring', stiffness: 260, damping: 26, delay: i * 0.08 }}
            >
              <Link
                href={isLocked ? '#' : `/stop/${stop.id}`}
                onClick={(e: React.MouseEvent) => { if (isLocked) e.preventDefault(); }}
                style={{ textDecoration: 'none', display: 'block' }}
              >
                <div
                  className="card"
                  style={{
                    padding: '18px 20px',
                    opacity: isLocked ? 0.45 : 1,
                    borderColor: stop.status === 'in-progress' ? 'var(--accent)' : undefined,
                    borderWidth: stop.status === 'in-progress' ? 1.5 : 1,
                    transition: 'all 0.2s ease',
                  }}
                >
                  <div style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
                    <div
                      style={{
                        width: 44, height: 44, borderRadius: 12, flexShrink: 0,
                        background: stop.status === 'done' ? 'var(--accent)' : stop.status === 'in-progress' ? 'rgba(245,158,11,0.15)' : '#333',
                        display: 'flex', alignItems: 'center', justifyContent: 'center',
                        border: stop.status === 'in-progress' ? '1.5px solid var(--accent)' : '1px solid var(--border)',
                      }}
                    >
                      <span className="font-display" style={{ fontSize: 18, color: stop.status === 'done' ? '#1a1a1a' : 'var(--text)' }}>
                        {STOP_NUMS[i]}
                      </span>
                    </div>

                    <div style={{ flex: 1, minWidth: 0 }}>
                      <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                        <span className="font-display" style={{ fontSize: 22, color: 'var(--text)', lineHeight: 1 }}>
                          {stop.name}
                        </span>
                      </div>
                      <div style={{ fontSize: 12, color: stop.status === 'in-progress' ? 'var(--accent)' : 'var(--text-muted)', marginTop: 3 }}>
                        {STATUS_LABEL[stop.status]}
                        {stop.burgerNames.length > 0 && (
                          <span> &middot; {stop.burgerNames.length} burger{stop.burgerNames.length !== 1 ? 's' : ''}</span>
                        )}
                      </div>
                    </div>

                    {avg !== null ? (
                      <div style={{ textAlign: 'right', flexShrink: 0 }}>
                        <div className="font-display" style={{ fontSize: 28, color: 'var(--accent)', lineHeight: 1 }}>
                          {avg.toFixed(1)}
                        </div>
                        <div style={{ fontSize: 11, color: 'var(--text-muted)' }}>avg</div>
                      </div>
                    ) : !isLocked ? (
                      <div style={{ color: 'var(--text-muted)', fontSize: 20 }}>›</div>
                    ) : null}
                  </div>
                </div>
              </Link>
            </motion.div>
          );
        })}
      </div>

      <div style={{ padding: '24px 20px 0' }}>
        <p style={{ fontSize: 11, color: 'var(--text-muted)', margin: '0 0 10px', textTransform: 'uppercase', letterSpacing: '0.08em' }}>
          Los jueces
        </p>
        <div style={{ display: 'flex', gap: 10 }}>
          {['Maida', 'Gena', 'Fran'].map(name => (
            <div
              key={name}
              style={{
                background: 'var(--bg-card)', border: '1px solid var(--border)',
                borderRadius: 20, padding: '8px 14px', fontSize: 13, color: 'var(--text)',
              }}
            >
              {name}
            </div>
          ))}
        </div>
      </div>
    </main>
  );
}
