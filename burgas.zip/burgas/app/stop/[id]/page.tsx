'use client';

import { use, useState } from 'react';
import { useRouter } from 'next/navigation';
import { motion, AnimatePresence } from 'framer-motion';
import {
  useTour,
  FRIENDS,
  Friend,
  BURGER_ATTRIBUTES,
  FRIES_ATTRIBUTES,
  isStopComplete,
  calcBurgerAvg,
  calcFriesAvg,
  BurgerRating,
  FriesRating,
} from '@/context/TourContext';
import RatingControl from '@/components/RatingControl';

// ─── Step 1: Enter burger names ───────────────────────────────────────────────

function BurgerSetup({
  stopId,
  names,
  onConfirm,
}: {
  stopId: number;
  names: string[];
  onConfirm: (names: string[]) => void;
}) {
  const [burgers, setBurgers] = useState<string[]>(names.length > 0 ? names : ['']);
  const [input, setInput] = useState('');

  const addBurger = () => {
    const trimmed = input.trim();
    if (!trimmed) return;
    setBurgers(prev => [...prev, trimmed]);
    setInput('');
  };

  const remove = (i: number) => setBurgers(prev => prev.filter((_, idx) => idx !== i));

  const canConfirm = burgers.length > 0;

  return (
    <div style={{ padding: '0 16px' }}>
      <h2 className="font-display" style={{ fontSize: 32, margin: '0 0 4px', color: 'var(--text)' }}>
        Burgers de la parada
      </h2>
      <p style={{ color: 'var(--text-muted)', fontSize: 14, margin: '0 0 20px' }}>
        Agregá los nombres de las burgers del menú
      </p>

      {/* Burger list */}
      <div style={{ display: 'flex', flexDirection: 'column', gap: 8, marginBottom: 16 }}>
        <AnimatePresence>
          {burgers.map((name, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, x: -12 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 12 }}
              transition={{ type: 'spring', stiffness: 300, damping: 28 }}
              style={{
                display: 'flex',
                alignItems: 'center',
                gap: 10,
                background: 'var(--bg-card)',
                border: '1px solid var(--border)',
                borderRadius: 12,
                padding: '12px 14px',
              }}
            >
              <span style={{ fontSize: 16 }}>🍔</span>
              <span style={{ flex: 1, fontSize: 15 }}>{name}</span>
              <button
                onClick={() => remove(i)}
                style={{
                  background: 'none',
                  border: 'none',
                  color: 'var(--text-muted)',
                  fontSize: 18,
                  cursor: 'pointer',
                  padding: '4px 8px',
                  minHeight: 44,
                  display: 'flex',
                  alignItems: 'center',
                }}
                type="button"
              >
                ✕
              </button>
            </motion.div>
          ))}
        </AnimatePresence>
      </div>

      {/* Add burger row */}
      <div style={{ display: 'flex', gap: 8, marginBottom: 24 }}>
        <input
          type="text"
          value={input}
          onChange={e => setInput(e.target.value)}
          placeholder="Nombre de la burger..."
          onKeyDown={e => e.key === 'Enter' && addBurger()}
          style={{ flex: 1 }}
        />
        <button
          onClick={addBurger}
          disabled={!input.trim()}
          type="button"
          style={{
            width: 48,
            height: 48,
            borderRadius: 12,
            background: input.trim() ? 'var(--accent)' : '#333',
            border: 'none',
            color: input.trim() ? '#1a1a1a' : 'var(--text-muted)',
            fontSize: 24,
            cursor: input.trim() ? 'pointer' : 'default',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            flexShrink: 0,
            transition: 'all 0.2s',
          }}
        >
          +
        </button>
      </div>

      {/* Also add fries info */}
      <div
        style={{
          background: 'rgba(245,158,11,0.08)',
          border: '1px solid rgba(245,158,11,0.25)',
          borderRadius: 12,
          padding: '12px 14px',
          display: 'flex',
          alignItems: 'center',
          gap: 10,
          marginBottom: 24,
        }}
      >
        <span style={{ fontSize: 18 }}>🍟</span>
        <span style={{ fontSize: 13, color: 'var(--text-muted)' }}>
          Las papas fritas se califican automáticamente en cada sección
        </span>
      </div>

      <button
        onClick={() => canConfirm && onConfirm(burgers)}
        disabled={!canConfirm}
        type="button"
        style={{
          width: '100%',
          padding: '16px',
          borderRadius: 14,
          background: canConfirm ? 'var(--accent)' : '#333',
          border: 'none',
          color: canConfirm ? '#1a1a1a' : 'var(--text-muted)',
          fontSize: 16,
          fontWeight: 700,
          cursor: canConfirm ? 'pointer' : 'default',
          transition: 'all 0.2s',
          minHeight: 52,
        }}
      >
        Empezar a calificar →
      </button>
    </div>
  );
}

// ─── Step 2: Rate items ───────────────────────────────────────────────────────

function RatingSection({ stopId }: { stopId: number }) {
  const { state, dispatch } = useTour();
  const router = useRouter();
  const stop = state.stops.find(s => s.id === stopId)!;
  const [activeFriend, setActiveFriend] = useState<Friend>(FRIENDS[0]);
  const [activeTab, setActiveTab] = useState<'burgers' | 'fries'>('burgers');
  const [activeBurger, setActiveBurger] = useState(0);

  const friendRatings = stop.ratings[activeFriend] ?? { burgers: stop.burgerNames.map((): BurgerRating => ({})), fries: {} as FriesRating };

  const setBurgerAttr = (burgerIdx: number, attr: typeof BURGER_ATTRIBUTES[number], value: number) => {
    dispatch({ type: 'SET_BURGER_RATING', stopId, friend: activeFriend, burgerIdx, attr, value });
  };

  const setFriesAttr = (attr: typeof FRIES_ATTRIBUTES[number], value: number) => {
    dispatch({ type: 'SET_FRIES_RATING', stopId, friend: activeFriend, attr, value });
  };

  const complete = isStopComplete(stop);

  const handleComplete = () => {
    dispatch({ type: 'COMPLETE_STOP', stopId });
    router.push('/');
  };

  // Progress per friend
  const friendProgress = (friend: Friend) => {
    const fr = stop.ratings[friend];
    if (!fr) return 0;
    let filled = 0;
    let total = 0;
    stop.burgerNames.forEach((_, i) => {
      BURGER_ATTRIBUTES.forEach(attr => {
        total++;
        if (fr.burgers?.[i]?.[attr] !== undefined) filled++;
      });
    });
    FRIES_ATTRIBUTES.forEach(attr => {
      total++;
      if (fr.fries?.[attr] !== undefined) filled++;
    });
    return total > 0 ? filled / total : 0;
  };

  return (
    <div>
      {/* Friend tabs */}
      <div style={{ padding: '0 16px 12px', overflowX: 'auto' }}>
        <div style={{ display: 'flex', gap: 8, minWidth: 'max-content' }}>
          {FRIENDS.map(friend => {
            const pct = friendProgress(friend);
            return (
              <button
                key={friend}
                onClick={() => setActiveFriend(friend)}
                className={`tab-pill ${activeFriend === friend ? 'active' : 'inactive'}`}
                type="button"
                style={{ position: 'relative' }}
              >
                {friend}
                {pct > 0 && pct < 1 && (
                  <span
                    style={{
                      marginLeft: 6,
                      fontSize: 11,
                      opacity: 0.7,
                    }}
                  >
                    {Math.round(pct * 100)}%
                  </span>
                )}
                {pct === 1 && <span style={{ marginLeft: 4 }}>✅</span>}
              </button>
            );
          })}
        </div>
      </div>

      {/* Burger / Fries tab */}
      <div style={{ padding: '0 16px 12px' }}>
        <div style={{ display: 'flex', gap: 8 }}>
          <button
            onClick={() => setActiveTab('burgers')}
            className={`tab-pill ${activeTab === 'burgers' ? 'active' : 'inactive'}`}
            type="button"
          >
            🍔 Burgers
          </button>
          <button
            onClick={() => setActiveTab('fries')}
            className={`tab-pill ${activeTab === 'fries' ? 'active' : 'inactive'}`}
            type="button"
          >
            🍟 Papas
          </button>
        </div>
      </div>

      <AnimatePresence mode="wait">
        {activeTab === 'burgers' ? (
          <motion.div
            key="burgers"
            initial={{ opacity: 0, x: -10 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: 10 }}
            transition={{ type: 'spring', stiffness: 300, damping: 28 }}
            style={{ padding: '0 16px' }}
          >
            {/* Burger selector */}
            {stop.burgerNames.length > 1 && (
              <div style={{ display: 'flex', gap: 8, marginBottom: 16, overflowX: 'auto' }}>
                {stop.burgerNames.map((name, i) => (
                  <button
                    key={i}
                    onClick={() => setActiveBurger(i)}
                    type="button"
                    style={{
                      padding: '8px 14px',
                      borderRadius: 12,
                      background: activeBurger === i ? 'rgba(245,158,11,0.15)' : '#333',
                      border: activeBurger === i ? '1.5px solid var(--accent)' : '1px solid var(--border)',
                      color: activeBurger === i ? 'var(--accent)' : 'var(--text-muted)',
                      fontSize: 13,
                      fontWeight: 600,
                      cursor: 'pointer',
                      whiteSpace: 'nowrap',
                      minHeight: 40,
                    }}
                  >
                    {name}
                  </button>
                ))}
              </div>
            )}

            {/* Burger name header */}
            <div
              style={{
                background: 'rgba(245,158,11,0.08)',
                border: '1px solid rgba(245,158,11,0.2)',
                borderRadius: 12,
                padding: '10px 14px',
                marginBottom: 16,
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'space-between',
              }}
            >
              <span style={{ fontSize: 15, fontWeight: 600 }}>
                🍔 {stop.burgerNames[activeBurger]}
              </span>
              {(() => {
                const avg = calcBurgerAvg(stop, activeBurger);
                return avg > 0 ? (
                  <span className="font-display" style={{ fontSize: 24, color: 'var(--accent)' }}>
                    {avg.toFixed(1)}
                  </span>
                ) : null;
              })()}
            </div>

            {/* Burger attributes */}
            <div
              className="card"
              style={{ padding: '16px' }}
            >
              {BURGER_ATTRIBUTES.map(attr => (
                <RatingControl
                  key={attr}
                  label={attr}
                  value={friendRatings.burgers?.[activeBurger]?.[attr]}
                  onChange={v => setBurgerAttr(activeBurger, attr, v)}
                />
              ))}
            </div>
          </motion.div>
        ) : (
          <motion.div
            key="fries"
            initial={{ opacity: 0, x: 10 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -10 }}
            transition={{ type: 'spring', stiffness: 300, damping: 28 }}
            style={{ padding: '0 16px' }}
          >
            {/* Fries header */}
            <div
              style={{
                background: 'rgba(245,158,11,0.08)',
                border: '1px solid rgba(245,158,11,0.2)',
                borderRadius: 12,
                padding: '10px 14px',
                marginBottom: 16,
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'space-between',
              }}
            >
              <span style={{ fontSize: 15, fontWeight: 600 }}>🍟 Papas fritas</span>
              {(() => {
                const avg = calcFriesAvg(stop);
                return avg > 0 ? (
                  <span className="font-display" style={{ fontSize: 24, color: 'var(--accent)' }}>
                    {avg.toFixed(1)}
                  </span>
                ) : null;
              })()}
            </div>

            <div className="card" style={{ padding: '16px' }}>
              {FRIES_ATTRIBUTES.map(attr => (
                <RatingControl
                  key={attr}
                  label={attr}
                  value={friendRatings.fries?.[attr]}
                  onChange={v => setFriesAttr(attr, v)}
                />
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Complete button */}
      <div style={{ padding: '24px 16px 0' }}>
        <button
          onClick={handleComplete}
          disabled={!complete}
          type="button"
          style={{
            width: '100%',
            padding: '16px',
            borderRadius: 14,
            background: complete ? 'var(--accent)' : '#333',
            border: 'none',
            color: complete ? '#1a1a1a' : 'var(--text-muted)',
            fontSize: 16,
            fontWeight: 700,
            cursor: complete ? 'pointer' : 'default',
            transition: 'all 0.3s',
            minHeight: 52,
          }}
        >
          {complete ? '✅ Completar parada' : 'Completá todas las calificaciones primero'}
        </button>
      </div>
    </div>
  );
}

// ─── Page ─────────────────────────────────────────────────────────────────────

export default function StopPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = use(params);
  const stopId = parseInt(id, 10);
  const { state, dispatch } = useTour();
  const stop = state.stops.find(s => s.id === stopId);

  if (!stop) {
    return (
      <main className="page-content" style={{ padding: '24px 16px' }}>
        <p style={{ color: 'var(--text-muted)' }}>Parada no encontrada</p>
      </main>
    );
  }

  if (stop.status === 'locked') {
    return (
      <main className="page-content" style={{ padding: '24px 16px' }}>
        <div style={{ textAlign: 'center', paddingTop: 60 }}>
          <div style={{ fontSize: 48 }}>🔒</div>
          <h2 className="font-display" style={{ fontSize: 28, margin: '12px 0 8px' }}>
            Parada bloqueada
          </h2>
          <p style={{ color: 'var(--text-muted)', fontSize: 14 }}>
            Completá las paradas anteriores primero
          </p>
        </div>
      </main>
    );
  }

  const setupDone = stop.burgerNames.length > 0;

  return (
    <main className="page-content" style={{ paddingLeft: 0, paddingRight: 0 }}>
      {/* Stop header */}
      <div style={{ padding: '16px 16px 20px' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          <span style={{ fontSize: 13, color: 'var(--text-muted)' }}>Parada {stop.id}/4</span>
          <span
            style={{
              fontSize: 12,
              color: stop.status === 'done' ? '#22c55e' : 'var(--accent)',
              background: stop.status === 'done' ? 'rgba(34,197,94,0.1)' : 'rgba(245,158,11,0.1)',
              border: `1px solid ${stop.status === 'done' ? 'rgba(34,197,94,0.3)' : 'rgba(245,158,11,0.3)'}`,
              borderRadius: 20,
              padding: '3px 10px',
            }}
          >
            {stop.status === 'done' ? '✅ Completada' : '🔥 En progreso'}
          </span>
        </div>
        <h1
          className="font-display"
          style={{ fontSize: 40, margin: '4px 0 0', color: 'var(--text)', lineHeight: 1 }}
        >
          {stop.name}
        </h1>
      </div>

      <AnimatePresence mode="wait">
        {!setupDone ? (
          <motion.div
            key="setup"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
          >
            <BurgerSetup
              stopId={stopId}
              names={stop.burgerNames}
              onConfirm={names =>
                dispatch({ type: 'SET_BURGER_NAMES', stopId, names })
              }
            />
          </motion.div>
        ) : (
          <motion.div
            key="rating"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
          >
            {stop.status === 'done' ? (
              <div style={{ padding: '0 16px', textAlign: 'center', paddingTop: 20 }}>
                <div style={{ fontSize: 48 }}>✅</div>
                <h2 className="font-display" style={{ fontSize: 28, margin: '8px 0' }}>
                  Parada completada
                </h2>
                <p style={{ color: 'var(--text-muted)', fontSize: 14 }}>
                  Esta parada ya fue calificada por todos
                </p>
              </div>
            ) : (
              <RatingSection stopId={stopId} />
            )}
          </motion.div>
        )}
      </AnimatePresence>
    </main>
  );
}
