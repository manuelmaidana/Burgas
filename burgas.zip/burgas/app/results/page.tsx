'use client';

import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useTour, FRIENDS, BURGER_ATTRIBUTES, FRIES_ATTRIBUTES, calcStopOverall, calcBurgerAvg, calcFriesAvg, Stop, Friend } from '@/context/TourContext';

function calcFriendStopScore(stop: Stop, friend: Friend): number {
  const fr = stop.ratings[friend];
  if (!fr) return 0;
  const vals: number[] = [];
  stop.burgerNames.forEach((_, i) => {
    BURGER_ATTRIBUTES.forEach(attr => {
      const v = fr.burgers?.[i]?.[attr];
      if (v !== undefined) vals.push(v);
    });
  });
  FRIES_ATTRIBUTES.forEach(attr => {
    const v = fr.fries?.[attr];
    if (v !== undefined) vals.push(v);
  });
  return vals.length ? vals.reduce((a, b) => a + b, 0) / vals.length : 0;
}

function ScoreBar({ score, delay = 0 }: { score: number; delay?: number }) {
  const pct = ((score - 1) / 9) * 100;
  return (
    <div style={{ height: 4, background: '#333', borderRadius: 2, overflow: 'hidden' }}>
      <motion.div
        initial={{ width: 0 }}
        animate={{ width: `${pct}%` }}
        transition={{ delay, duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
        style={{
          height: '100%',
          background: 'var(--accent)',
          borderRadius: 2,
        }}
      />
    </div>
  );
}

function StopCard({ stop, rank, delay }: { stop: Stop; rank: number; delay: number }) {
  const [expanded, setExpanded] = useState(false);
  const overall = calcStopOverall(stop);
  const isWinner = rank === 1;

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ type: 'spring', stiffness: 260, damping: 26, delay }}
    >
      <button
        onClick={() => setExpanded(e => !e)}
        type="button"
        style={{
          width: '100%',
          background: 'none',
          border: 'none',
          padding: 0,
          cursor: 'pointer',
          textAlign: 'left',
        }}
      >
        <div
          className="card"
          style={{
            padding: '16px 18px',
            borderColor: isWinner ? 'var(--accent)' : undefined,
            borderWidth: isWinner ? 1.5 : 1,
            marginBottom: expanded ? 0 : 0,
            borderRadius: expanded ? '16px 16px 0 0' : 16,
            transition: 'border-radius 0.2s',
          }}
        >
          <div style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
            {/* Rank badge */}
            <div
              style={{
                width: 44,
                height: 44,
                borderRadius: 12,
                background: isWinner ? 'var(--accent)' : '#333',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                flexShrink: 0,
              }}
            >
              <span
                className="font-display"
                style={{ fontSize: 22, color: isWinner ? '#1a1a1a' : 'var(--text)' }}
              >
                {isWinner ? '🏆' : `#${rank}`}
              </span>
            </div>

            <div style={{ flex: 1 }}>
              <div style={{ display: 'flex', alignItems: 'baseline', gap: 6 }}>
                <span className="font-display" style={{ fontSize: 24 }}>{stop.name}</span>
                {isWinner && <span style={{ fontSize: 12, color: 'var(--accent)', fontWeight: 600 }}>GANADOR</span>}
              </div>
              <div style={{ marginTop: 6 }}>
                <ScoreBar score={overall} delay={delay + 0.2} />
              </div>
            </div>

            <div style={{ textAlign: 'right', flexShrink: 0 }}>
              <motion.div
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: delay + 0.3, type: 'spring', stiffness: 300, damping: 20 }}
                className="font-display"
                style={{ fontSize: 32, color: 'var(--accent)', lineHeight: 1 }}
              >
                {overall.toFixed(2)}
              </motion.div>
              <div style={{ fontSize: 11, color: 'var(--text-muted)' }}>/ 10.00</div>
            </div>
          </div>
        </div>
      </button>

      <AnimatePresence>
        {expanded && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ type: 'spring', stiffness: 300, damping: 30 }}
            style={{ overflow: 'hidden' }}
          >
            <div
              style={{
                background: 'var(--bg-card)',
                border: '1.5px solid var(--border)',
                borderTop: 'none',
                borderRadius: '0 0 16px 16px',
                padding: '16px 18px',
              }}
            >
              {/* Per-friend scores */}
              <div style={{ marginBottom: 16 }}>
                <p style={{ fontSize: 11, color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.08em', margin: '0 0 10px' }}>
                  Por juez
                </p>
                {FRIENDS.map(friend => {
                  const score = calcFriendStopScore(stop, friend);
                  return (
                    <div key={friend} style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 8 }}>
                      <span style={{ width: 48, fontSize: 13, color: 'var(--text-muted)', flexShrink: 0 }}>{friend}</span>
                      <div style={{ flex: 1 }}>
                        <div style={{ height: 3, background: '#333', borderRadius: 2, overflow: 'hidden' }}>
                          <div
                            style={{
                              height: '100%',
                              width: `${((score - 1) / 9) * 100}%`,
                              background: 'var(--accent)',
                              borderRadius: 2,
                              opacity: 0.7,
                            }}
                          />
                        </div>
                      </div>
                      <span style={{ fontSize: 13, fontWeight: 700, color: 'var(--text)', width: 36, textAlign: 'right', fontVariantNumeric: 'tabular-nums' }}>
                        {score > 0 ? score.toFixed(1) : '—'}
                      </span>
                    </div>
                  );
                })}
              </div>

              {/* Burger scores */}
              <div style={{ marginBottom: 12 }}>
                <p style={{ fontSize: 11, color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.08em', margin: '0 0 10px' }}>
                  Burgers
                </p>
                {stop.burgerNames.map((name, i) => {
                  const avg = calcBurgerAvg(stop, i);
                  return (
                    <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 8 }}>
                      <span style={{ fontSize: 13, flex: 1, color: 'var(--text)' }}>🍔 {name}</span>
                      <span style={{ fontSize: 14, fontWeight: 700, color: 'var(--accent)', fontVariantNumeric: 'tabular-nums' }}>
                        {avg > 0 ? avg.toFixed(2) : '—'}
                      </span>
                    </div>
                  );
                })}
              </div>

              {/* Fries */}
              <div>
                <p style={{ fontSize: 11, color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.08em', margin: '0 0 8px' }}>
                  Papas fritas
                </p>
                <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                  <span style={{ fontSize: 13, flex: 1, color: 'var(--text)' }}>🍟 Papas</span>
                  <span style={{ fontSize: 14, fontWeight: 700, color: 'var(--accent)', fontVariantNumeric: 'tabular-nums' }}>
                    {calcFriesAvg(stop) > 0 ? calcFriesAvg(stop).toFixed(2) : '—'}
                  </span>
                </div>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
}

function CategoryWinners({ stops }: { stops: Stop[] }) {
  // Best per burger attribute
  type Winner = { stop: Stop; score: number } | null;

  const burgerWinners = BURGER_ATTRIBUTES.map(attr => {
    const best: Winner = stops.reduce<Winner>((acc, stop) => {
      return stop.burgerNames.reduce<Winner>((inner, _, i) => {
        const vals: number[] = [];
        FRIENDS.forEach(friend => {
          const v = stop.ratings[friend]?.burgers?.[i]?.[attr];
          if (v !== undefined) vals.push(v);
        });
        const avg = vals.length ? vals.reduce((a, b) => a + b, 0) / vals.length : 0;
        return (!inner || avg > inner.score) ? { stop, score: avg } : inner;
      }, acc);
    }, null);
    return { attr, best };
  });

  const friesWinners = FRIES_ATTRIBUTES.map(attr => {
    const best: Winner = stops.reduce<Winner>((acc, stop) => {
      const vals: number[] = [];
      FRIENDS.forEach(friend => {
        const v = stop.ratings[friend]?.fries?.[attr];
        if (v !== undefined) vals.push(v);
      });
      const avg = vals.length ? vals.reduce((a, b) => a + b, 0) / vals.length : 0;
      return (!acc || avg > acc.score) ? { stop, score: avg } : acc;
    }, null);
    return { attr, best };
  });

  return (
    <motion.div
      initial={{ opacity: 0, y: 16 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.6 }}
      style={{ padding: '0 16px' }}
    >
      <h3 className="font-display" style={{ fontSize: 24, margin: '0 0 12px', color: 'var(--text)' }}>
        🏆 Mejores categorías
      </h3>

      <div className="card" style={{ padding: '12px 16px', marginBottom: 16 }}>
        <p style={{ fontSize: 12, color: 'var(--text-muted)', margin: '0 0 10px', textTransform: 'uppercase', letterSpacing: '0.06em' }}>
          Burgers
        </p>
        {burgerWinners.map(({ attr, best }) => (
          <div key={attr} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '6px 0', borderBottom: '1px solid var(--border)' }}>
            <span style={{ fontSize: 13, color: 'var(--text-muted)' }}>{attr}</span>
            <div style={{ textAlign: 'right' }}>
              <span style={{ fontSize: 13, fontWeight: 700, color: 'var(--text)' }}>
                {best !== null ? best.stop.name : '—'}
              </span>
              {best && (
                <span style={{ fontSize: 12, color: 'var(--accent)', marginLeft: 8 }}>
                  {best.score.toFixed(1)}
                </span>
              )}
            </div>
          </div>
        ))}
      </div>

      <div className="card" style={{ padding: '12px 16px' }}>
        <p style={{ fontSize: 12, color: 'var(--text-muted)', margin: '0 0 10px', textTransform: 'uppercase', letterSpacing: '0.06em' }}>
          Papas fritas
        </p>
        {friesWinners.map(({ attr, best }) => (
          <div key={attr} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '6px 0', borderBottom: '1px solid var(--border)' }}>
            <span style={{ fontSize: 13, color: 'var(--text-muted)' }}>{attr}</span>
            <div style={{ textAlign: 'right' }}>
              <span style={{ fontSize: 13, fontWeight: 700, color: 'var(--text)' }}>
                {best !== null ? best.stop.name : '—'}
              </span>
              {best && (
                <span style={{ fontSize: 12, color: 'var(--accent)', marginLeft: 8 }}>
                  {best.score.toFixed(1)}
                </span>
              )}
            </div>
          </div>
        ))}
      </div>
    </motion.div>
  );
}

export default function ResultsPage() {
  const { state } = useTour();
  const allDone = state.stops.every(s => s.status === 'done');

  if (!allDone) {
    return (
      <main className="page-content" style={{ padding: '24px 16px' }}>
        <div style={{ textAlign: 'center', paddingTop: 60 }}>
          <div style={{ fontSize: 48 }}>🔒</div>
          <h2 className="font-display" style={{ fontSize: 28, margin: '12px 0 8px' }}>
            Resultados bloqueados
          </h2>
          <p style={{ color: 'var(--text-muted)', fontSize: 14 }}>
            Completá las 4 paradas para ver el ranking final
          </p>
        </div>
      </main>
    );
  }

  // Sort stops by overall score desc
  const ranked = [...state.stops].sort((a, b) => calcStopOverall(b) - calcStopOverall(a));

  return (
    <main className="page-content" style={{ paddingLeft: 0, paddingRight: 0, paddingTop: 'calc(16px + env(safe-area-inset-top, 0px))' }}>
      {/* Header */}
      <div style={{ padding: '8px 16px 20px' }}>
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ type: 'spring', stiffness: 300, damping: 24 }}
        >
          <h1 className="font-display" style={{ fontSize: 44, margin: 0, lineHeight: 1 }}>
            🏆 Resultados
          </h1>
          <p style={{ color: 'var(--text-muted)', fontSize: 14, margin: '6px 0 0' }}>
            La mejor burger de todas
          </p>
        </motion.div>
      </div>

      {/* Winner spotlight */}
      <motion.div
        initial={{ opacity: 0, y: 12 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.15 }}
        style={{
          margin: '0 16px 20px',
          background: 'linear-gradient(135deg, rgba(245,158,11,0.15), rgba(245,158,11,0.05))',
          border: '1.5px solid rgba(245,158,11,0.4)',
          borderRadius: 20,
          padding: '20px',
          textAlign: 'center',
        }}
      >
        <div style={{ fontSize: 40 }}>🏆</div>
        <div className="font-display" style={{ fontSize: 36, color: 'var(--accent)', margin: '4px 0 2px' }}>
          {ranked[0].name}
        </div>
        <div style={{ fontSize: 13, color: 'var(--text-muted)' }}>
          {calcStopOverall(ranked[0]).toFixed(2)} / 10.00 — La campeona
        </div>
      </motion.div>

      {/* Rankings */}
      <div style={{ padding: '0 16px', display: 'flex', flexDirection: 'column', gap: 12, marginBottom: 24 }}>
        {ranked.map((stop, i) => (
          <StopCard key={stop.id} stop={stop} rank={i + 1} delay={i * 0.1 + 0.2} />
        ))}
      </div>

      {/* Category winners */}
      <CategoryWinners stops={state.stops} />

      <div style={{ height: 24 }} />
    </main>
  );
}
