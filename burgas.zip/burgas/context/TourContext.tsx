'use client';

import React, { createContext, useContext, useEffect, useReducer, ReactNode } from 'react';

// ─── Types ───────────────────────────────────────────────────────────────────

export const FRIENDS = ['Maida', 'Gena', 'Fran'] as const;
export type Friend = typeof FRIENDS[number];

export const RESTAURANTS = ['Luisa\'s', 'Grasa', 'Fino', 'Guita'] as const;
export type Restaurant = typeof RESTAURANTS[number];

export const BURGER_ATTRIBUTES = [
  'Pan',
  'Punto de la carne',
  'Salsas',
  'Sabor',
  'Personalidad',
  'Originalidad',
  'Calidad/precio',
] as const;
export type BurgerAttribute = typeof BURGER_ATTRIBUTES[number];

export const FRIES_ATTRIBUTES = [
  'Crocante',
  'Condimentacion',
  'Textura general',
  'Personalidad',
  'Originalidad',
  'Calidad/precio',
] as const;
export type FriesAttribute = typeof FRIES_ATTRIBUTES[number];

export type BurgerRating = { [K in BurgerAttribute]?: number };
export type FriesRating = { [K in FriesAttribute]?: number };

export interface FriendRatings {
  burgers: BurgerRating[];
  fries: FriesRating;
}

export type StopStatus = 'locked' | 'in-progress' | 'done';

export interface Stop {
  id: number;
  name: Restaurant;
  status: StopStatus;
  burgerNames: string[];
  ratings: { [F in Friend]?: FriendRatings };
}

export interface TourState {
  stops: Stop[];
  currentStopId: number;
}

// ─── Initial State ────────────────────────────────────────────────────────────

const initialStops: Stop[] = RESTAURANTS.map((name, i) => ({
  id: i + 1,
  name,
  status: i === 0 ? 'in-progress' : 'locked',
  burgerNames: [],
  ratings: {},
}));

const initialState: TourState = {
  stops: initialStops,
  currentStopId: 1,
};

// ─── Actions ──────────────────────────────────────────────────────────────────

type Action =
  | { type: 'SET_BURGER_NAMES'; stopId: number; names: string[] }
  | { type: 'SET_BURGER_RATING'; stopId: number; friend: Friend; burgerIdx: number; attr: BurgerAttribute; value: number }
  | { type: 'SET_FRIES_RATING'; stopId: number; friend: Friend; attr: FriesAttribute; value: number }
  | { type: 'COMPLETE_STOP'; stopId: number }
  | { type: 'LOAD_STATE'; state: TourState };

// ─── Reducer ──────────────────────────────────────────────────────────────────

function reducer(state: TourState, action: Action): TourState {
  switch (action.type) {
    case 'LOAD_STATE':
      return action.state;

    case 'SET_BURGER_NAMES': {
      return {
        ...state,
        stops: state.stops.map(s =>
          s.id === action.stopId
            ? { ...s, burgerNames: action.names, ratings: {} }
            : s
        ),
      };
    }

    case 'SET_BURGER_RATING': {
      return {
        ...state,
        stops: state.stops.map(s => {
          if (s.id !== action.stopId) return s;
          const prevFriend: FriendRatings = s.ratings[action.friend] ?? {
            burgers: s.burgerNames.map(() => ({} as BurgerRating)),
            fries: {} as FriesRating,
          };
          const prevBurgers = [...(prevFriend.burgers ?? s.burgerNames.map(() => ({})))];
          prevBurgers[action.burgerIdx] = {
            ...prevBurgers[action.burgerIdx],
            [action.attr]: action.value,
          };
          return {
            ...s,
            ratings: {
              ...s.ratings,
              [action.friend]: { ...prevFriend, burgers: prevBurgers },
            },
          };
        }),
      };
    }

    case 'SET_FRIES_RATING': {
      return {
        ...state,
        stops: state.stops.map(s => {
          if (s.id !== action.stopId) return s;
          const prevFriend: FriendRatings = s.ratings[action.friend] ?? {
            burgers: s.burgerNames.map(() => ({} as BurgerRating)),
            fries: {} as FriesRating,
          };
          return {
            ...s,
            ratings: {
              ...s.ratings,
              [action.friend]: {
                ...prevFriend,
                fries: { ...prevFriend.fries, [action.attr]: action.value },
              },
            },
          };
        }),
      };
    }

    case 'COMPLETE_STOP': {
      const stops = state.stops.map(s => {
        if (s.id === action.stopId) return { ...s, status: 'done' as StopStatus };
        if (s.id === action.stopId + 1) return { ...s, status: 'in-progress' as StopStatus };
        return s;
      });
      return {
        ...state,
        stops,
        currentStopId: Math.min(action.stopId + 1, 4),
      };
    }

    default:
      return state;
  }
}

// ─── Helpers ──────────────────────────────────────────────────────────────────

export function isStopComplete(stop: Stop): boolean {
  if (stop.burgerNames.length === 0) return false;
  return FRIENDS.every(friend => {
    const fr = stop.ratings[friend];
    if (!fr) return false;
    // All burger attributes filled
    const burgersOk = stop.burgerNames.every((_, i) =>
      BURGER_ATTRIBUTES.every(attr => fr.burgers?.[i]?.[attr] !== undefined)
    );
    // All fries attributes filled
    const friesOk = FRIES_ATTRIBUTES.every(attr => fr.fries?.[attr] !== undefined);
    return burgersOk && friesOk;
  });
}

export function calcBurgerAvg(stop: Stop, burgerIdx: number): number {
  const vals: number[] = [];
  FRIENDS.forEach(friend => {
    const fr = stop.ratings[friend];
    if (!fr?.burgers?.[burgerIdx]) return;
    BURGER_ATTRIBUTES.forEach(attr => {
      const v = fr.burgers[burgerIdx][attr];
      if (v !== undefined) vals.push(v);
    });
  });
  return vals.length ? vals.reduce((a, b) => a + b, 0) / vals.length : 0;
}

export function calcFriesAvg(stop: Stop): number {
  const vals: number[] = [];
  FRIENDS.forEach(friend => {
    const fr = stop.ratings[friend];
    if (!fr?.fries) return;
    FRIES_ATTRIBUTES.forEach(attr => {
      const v = fr.fries[attr];
      if (v !== undefined) vals.push(v);
    });
  });
  return vals.length ? vals.reduce((a, b) => a + b, 0) / vals.length : 0;
}

export function calcStopOverall(stop: Stop): number {
  const burgerAvgs = stop.burgerNames.map((_, i) => calcBurgerAvg(stop, i));
  const friesAvg = calcFriesAvg(stop);
  const all = [...burgerAvgs, friesAvg].filter(v => v > 0);
  return all.length ? all.reduce((a, b) => a + b, 0) / all.length : 0;
}

// ─── Context ──────────────────────────────────────────────────────────────────

interface TourContextValue {
  state: TourState;
  dispatch: React.Dispatch<Action>;
}

const TourContext = createContext<TourContextValue | null>(null);

export function TourProvider({ children }: { children: ReactNode }) {
  const [state, dispatch] = useReducer(reducer, initialState);

  useEffect(() => {
    try {
      const saved = localStorage.getItem('burger-tour-state');
      if (saved) {
        dispatch({ type: 'LOAD_STATE', state: JSON.parse(saved) });
      }
    } catch {}
  }, []);

  useEffect(() => {
    try {
      localStorage.setItem('burger-tour-state', JSON.stringify(state));
    } catch {}
  }, [state]);

  return <TourContext.Provider value={{ state, dispatch }}>{children}</TourContext.Provider>;
}

export function useTour() {
  const ctx = useContext(TourContext);
  if (!ctx) throw new Error('useTour must be used inside TourProvider');
  return ctx;
}
