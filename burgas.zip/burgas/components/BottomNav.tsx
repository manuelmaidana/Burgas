'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { useTour } from '@/context/TourContext';

export default function BottomNav() {
  const pathname = usePathname();
  const { state } = useTour();

  const allDone = state.stops.every(s => s.status === 'done');
  const activeStop = state.stops.find(s => s.status === 'in-progress') ?? state.stops[state.currentStopId - 1];

  const items = [
    { href: '/', label: 'Home', emoji: '🏠' },
    {
      href: `/stop/${activeStop?.id ?? 1}`,
      label: 'Current',
      emoji: '🍔',
    },
    {
      href: allDone ? '/results' : '#',
      label: 'Results',
      emoji: '🏆',
      locked: !allDone,
    },
  ];

  return (
    <nav className="bottom-nav">
      <div style={{ display: 'flex', alignItems: 'stretch' }}>
        {items.map(item => {
          const isActive =
            item.href !== '#' &&
            (item.href === '/' ? pathname === '/' : pathname.startsWith(item.href.split('?')[0]));

          return (
            <Link
              key={item.href}
              href={item.locked ? '#' : item.href}
              style={{
                flex: 1,
                display: 'flex',
                flexDirection: 'column',
                alignItems: 'center',
                justifyContent: 'center',
                padding: '10px 0 12px',
                gap: 4,
                textDecoration: 'none',
                opacity: item.locked ? 0.35 : 1,
                cursor: item.locked ? 'default' : 'pointer',
                minHeight: 60,
                transition: 'opacity 0.2s',
              }}
              onClick={(e: React.MouseEvent) => { if (item.locked) e.preventDefault(); }}
            >
              <span style={{ fontSize: 22, lineHeight: 1 }}>{item.emoji}</span>
              <span
                style={{
                  fontSize: 11,
                  fontWeight: 600,
                  letterSpacing: '0.03em',
                  color: isActive ? 'var(--accent)' : 'var(--text-muted)',
                  transition: 'color 0.2s',
                }}
              >
                {item.label}
              </span>
              {isActive && (
                <span
                  style={{
                    position: 'absolute',
                    bottom: 0,
                    width: 4,
                    height: 4,
                    borderRadius: '50%',
                    background: 'var(--accent)',
                  }}
                />
              )}
            </Link>
          );
        })}
      </div>
    </nav>
  );
}
