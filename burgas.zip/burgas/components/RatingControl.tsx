'use client';

interface RatingControlProps {
  value: number | undefined;
  onChange: (v: number) => void;
  label: string;
}

export default function RatingControl({ value, onChange, label }: RatingControlProps) {
  const display = value !== undefined ? value.toFixed(2) : '—';
  const STEP = 0.25;

  const dec = () => {
    const cur = value ?? 5;
    onChange(Math.max(1, parseFloat((cur - STEP).toFixed(2))));
  };

  const inc = () => {
    const cur = value ?? 5;
    onChange(Math.min(10, parseFloat((cur + STEP).toFixed(2))));
  };

  const pct = value !== undefined ? ((value - 1) / 9) * 100 : 0;

  return (
    <div style={{ marginBottom: 14 }}>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 6 }}>
        <span style={{ fontSize: 13, color: 'var(--text-muted)', flex: 1 }}>{label}</span>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          <button
            className="stepper-btn"
            onClick={dec}
            aria-label={`Decrease ${label}`}
            type="button"
          >
            −
          </button>
          <span
            style={{
              fontSize: 18,
              fontWeight: 700,
              color: value !== undefined ? 'var(--accent)' : 'var(--text-muted)',
              width: 52,
              textAlign: 'center',
              fontVariantNumeric: 'tabular-nums',
            }}
          >
            {display}
          </span>
          <button
            className="stepper-btn"
            onClick={inc}
            aria-label={`Increase ${label}`}
            type="button"
          >
            +
          </button>
        </div>
      </div>
      {/* Mini progress bar */}
      <div style={{ height: 3, background: '#333', borderRadius: 2, overflow: 'hidden' }}>
        <div
          style={{
            height: '100%',
            width: `${pct}%`,
            background: 'var(--accent)',
            borderRadius: 2,
            transition: 'width 0.2s ease',
            opacity: value !== undefined ? 1 : 0,
          }}
        />
      </div>
    </div>
  );
}
